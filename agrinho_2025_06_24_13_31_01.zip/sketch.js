let arvores = [];

function setup() {
  createCanvas(800, 600);
  background(200, 255, 200); // verde claro
  textAlign(LEFT, TOP);
  textSize(20);
}

function draw() {
  background(200, 255, 200); // redesenha fundo

  // Mostrar todas as árvores
  for (let i = 0; i < arvores.length; i++) {
    desenharArvore(arvores[i].x, arvores[i].y);
  }

  // Mostrar contador
  fill(0);
  text("Árvores plantadas: " + arvores.length, 10, 10);
}

// Quando o mouse for clicado, planta uma árvore
function mousePressed() {
  arvores.push({ x: mouseX, y: mouseY });
}

// Função para desenhar uma árvore simples
function desenharArvore(x, y) {
  // Tronco
  fill(101, 67, 33);
  rect(x - 5, y, 10, 30);

  // Copa
  fill(34, 139, 34);
  ellipse(x, y, 40, 40);
}


